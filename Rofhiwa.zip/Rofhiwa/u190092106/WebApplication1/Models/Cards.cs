﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Cards
    {
        public int CardNumber { get; set; }
        public int CVV { get; set; }
        public string AccountType { get; set; }
    }
}