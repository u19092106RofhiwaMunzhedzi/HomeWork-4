﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Sponsers: Setha
    {
        public string Occupation { get; set; }
        public string CompanyName { get; set; }
        public string Loccation { get; set; }
        public string Discripton { get; set; }
       
       
    }
}