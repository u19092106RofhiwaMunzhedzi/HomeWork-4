﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
   public class Events: Setha
    {
        public string EventName { get; set; } 
        public DateTime EventDate { get; set; }
        public string EventTime { get; set; }
        public string Location { get; set; }
        public string Discription { get; set; }
              
    }
}