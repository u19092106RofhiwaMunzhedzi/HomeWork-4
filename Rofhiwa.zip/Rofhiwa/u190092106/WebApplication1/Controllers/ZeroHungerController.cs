﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ZeroHungerController : Controller
    {
        // GET: ZeroHunger
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login(string Username, string password)
        {
            Users user = new Users();
           if(ViewBag.Users == Username && ViewBag.Users == password)
            {
                return View();
            }
            return View();
        }
        public ActionResult Register( string Name , string Surname, string Username, string Email, string Password)
        {
            Users user = new Users();
            user.Username = Username;
            user.Surname = Surname;
            user.Name = Name;
            user.Email = Email;
            user.Password = Password;
            ViewBag.Users = user;
            
            return View();
        }
        public ActionResult Donate()
        {
            int Amount;
            Donations amount = new Donations();
            Amount = 0;
            amount.Amount = Amount;
            ViewBag.Amount = Amount;
            return View();
        }
        string Accountholder; int CardNumber; int CVV; string AccountType;
        public ActionResult Payment()
        {
            Cards cards = new Cards();
            cards.CardNumber = CardNumber;
            cards.CVV = CVV;
            cards.AccountType = AccountType;
            ViewBag.Cards = cards;
            return View();
        }
        public ActionResult Success()
        {
            return View();
        }
      
    }
}